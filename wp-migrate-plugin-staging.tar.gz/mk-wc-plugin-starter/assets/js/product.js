(function($){
  'use strict';
  $(function(){
    if (typeof MK_WCPS !== 'undefined') {
      console.log('MK WC Plugin Starter loaded', MK_WCPS);
    }
  });
})(jQuery);
